"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Archive, ArrowRight, LoaderCircle } from "lucide-react";

type Cabinet = { id: string; name: string; created_at: string; closed_at: string | null; theme_count: number };

export default function MyCabinets() {
  const [cabinets, setCabinets] = useState<Cabinet[] | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    void fetch("/api/auth/cabinets").then(async (response) => {
      if (response.status === 401) { window.location.replace("/?returnTo=%2Fmy"); return; }
      const body = await response.json() as { cabinets: Cabinet[]; error?: string };
      if (!response.ok) throw new Error(body.error);
      setCabinets(body.cabinets);
    }).catch((reason) => setError(reason instanceof Error ? reason.message : "读取失败"));
  }, []);
  if (!cabinets && !error) return <main className="grid min-h-screen place-items-center bg-[#eef4f3]"><LoaderCircle className="size-7 animate-spin text-[#17836d]" /></main>;
  if (error) return <main className="grid min-h-screen place-items-center bg-[#eef4f3] px-5"><div className="rounded-3xl bg-white p-8 text-center"><h1 className="text-2xl font-bold">读取智能柜失败</h1><p className="mt-2">{error}</p><Link href="/" className="mt-5 inline-block rounded-xl bg-[#123047] px-4 py-2.5 font-semibold text-white">返回首页</Link></div></main>;
  const list = cabinets ?? [];
  return <main className="min-h-screen bg-[#eef4f3] text-[#123047]"><div className="mx-auto max-w-5xl px-4 py-5 sm:px-8 sm:py-8">
    <header className="flex items-center justify-between gap-3"><Link href="/" className="flex min-w-0 items-center gap-3"><span className="grid size-10 shrink-0 place-items-center rounded-xl bg-[#123047] text-white"><Archive className="size-5" /></span><span><b className="block">柜联</b><small className="text-[#668087]">我的智能柜</small></span></Link><Link href="/" className="inline-flex min-h-11 shrink-0 items-center rounded-xl border border-[#c7d8d6] bg-white px-3 text-sm font-semibold">创建智能柜</Link></header>
    <section className="mt-10 sm:mt-12"><p className="text-sm text-[#67828a]">登录账号创建的空间</p><h1 className="mt-1 text-3xl font-extrabold sm:text-4xl">我的智能柜</h1>
      {list.length ? <div className="mt-6 grid gap-3 sm:mt-7 sm:grid-cols-2 sm:gap-4">{list.map((cabinet) => <Link key={cabinet.id} href={`/my/cabinets/${cabinet.id}`} className="rounded-3xl border border-[#cfe0dd] bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md sm:p-6"><p className="text-sm text-[#67828a]">{cabinet.closed_at ? "已关闭" : `${cabinet.theme_count} 个主题`}</p><h2 className="mt-2 break-words text-xl font-bold">{cabinet.name}</h2><p className="mt-2 text-sm text-[#728b91]">创建于 {new Date(cabinet.created_at).toLocaleDateString("zh-CN")}</p><span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-[#17836d]">查看与管理 <ArrowRight className="size-4" /></span></Link>)}</div> : <div className="mt-7 rounded-3xl border border-dashed border-[#c5d9d5] bg-white/70 px-5 py-10 text-center sm:p-12"><h2 className="text-lg font-bold">还没有智能柜</h2><p className="mt-2 text-[#718a90]">创建的智能柜会出现在这里。</p><Link href="/" className="mt-5 inline-flex min-h-11 items-center rounded-xl bg-[#123047] px-4 py-2.5 font-semibold text-white">去创建</Link></div>}
    </section>
  </div></main>;
}
