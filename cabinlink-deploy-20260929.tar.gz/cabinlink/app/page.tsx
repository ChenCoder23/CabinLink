"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Archive, ArrowRight, Copy, Link2, LoaderCircle, Plus, Settings2, Upload, UserRound } from "lucide-react";
import { toast } from "sonner";
import { AuthPanel, type AuthUser } from "@/components/auth-panel";
import { copyText } from "@/lib/copy-client";

function safeReturnTo() {
  const value = new URLSearchParams(window.location.search).get("returnTo");
  if (!value || !value.startsWith("/") || value.startsWith("//")) return null;
  try { const url = new URL(value, window.location.origin); return url.origin === window.location.origin ? url.pathname + url.search + url.hash : null; }
  catch { return null; }
}
async function copy(value: string) { await copyText(value); toast.success("链接已复制"); }

export default function Home() {
  const [name, setName] = useState("");
  const [joinLink, setJoinLink] = useState("");
  const [creating, setCreating] = useState(false);
  const [created, setCreated] = useState<{ shareUrl: string; adminUrl: string; cabinet: { name: string } } | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [checkingSession, setCheckingSession] = useState(true);

  const createCabinet = useCallback(async (requestedName: string) => {
    if (!requestedName.trim()) { toast.error("请先给智能柜起个名字"); return null; }
    setCreating(true);
    try {
      const response = await fetch("/api/cabinets", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: requestedName }) });
      const body = await response.json() as { error?: string; shareUrl: string; adminUrl: string; cabinet: { name: string } };
      if (response.status === 401) { setUser(null); throw new Error("登录已过期，请重新登录"); }
      if (!response.ok) throw new Error(body.error);
      setCreated(body); toast.success("智能柜已创建"); return body;
    } catch (error) { toast.error(error instanceof Error ? error.message : "创建失败，请重试"); return null; }
    finally { setCreating(false); }
  }, []);

  useEffect(() => {
    const context = (document as Document & { modelContext?: { registerTool?: (tool: unknown, options?: { signal: AbortSignal }) => unknown } }).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    void Promise.resolve(context.registerTool({
      name: "create_cabinlink_cabinet", title: "创建智能柜", description: "为当前登录账号创建文件共享智能柜，并返回分享与管理链接。",
      inputSchema: { type: "object", properties: { name: { type: "string", description: "智能柜名称" } }, required: ["name"], additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      async execute(input: unknown) {
        const requestedName = typeof input === "object" && input !== null && "name" in input ? (input as { name?: unknown }).name : undefined;
        if (typeof requestedName !== "string" || !requestedName.trim()) throw new Error("name 必须是非空字符串");
        const result = await createCabinet(requestedName);
        if (!result) throw new Error("创建智能柜失败");
        return { shareUrl: result.shareUrl, adminUrl: result.adminUrl };
      },
    }, { signal: lifecycle.signal })).catch(() => undefined);
    return () => lifecycle.abort();
  }, [createCabinet]);
  useEffect(() => {
    void fetch("/api/auth/session").then(async (response) => {
      if (!response.ok) throw new Error("读取登录状态失败");
      return response.json();
    }).then((body) => setUser((body as { user: AuthUser | null }).user ?? null)).catch(() => setUser(null)).finally(() => setCheckingSession(false));
  }, []);
  useEffect(() => { if (user) { const destination = safeReturnTo(); if (destination && destination !== "/") window.location.replace(destination); } }, [user]);

  async function logout() {
    const response = await fetch("/api/auth/session", { method: "DELETE" });
    if (!response.ok) return toast.error("退出失败，请重试");
    setUser(null); setCreated(null); toast.success("已退出登录");
  }
  function joinCabinet(event: React.FormEvent) {
    event.preventDefault();
    try {
      const url = new URL(joinLink.trim(), window.location.origin);
      if (url.origin !== window.location.origin || !/^\/(c|manage)\/[A-Za-z0-9_-]{32,}$/.test(url.pathname)) throw new Error();
      window.location.assign(url.pathname);
    } catch { toast.error("请粘贴有效的智能柜链接"); }
  }

  if (checkingSession) return <main className="grid min-h-screen place-items-center bg-[#edf4f2]"><LoaderCircle className="size-7 animate-spin text-[#17836d]" /></main>;
  if (!user) return <AuthPanel onAuthenticated={setUser} />;

  return <main className="min-h-screen bg-[#edf4f2] text-[#123047]"><div className="mx-auto max-w-6xl px-4 pb-9 pt-5 sm:px-8 sm:py-10">
    <header className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
      <Link href="/" className="flex items-center gap-3 self-start"><span className="grid size-11 place-items-center rounded-2xl bg-[#123047] text-white shadow-sm"><Archive className="size-5" /></span><span><b className="block text-lg leading-tight">柜联</b><small className="text-[#54707d]">CabinLink</small></span></Link>
      <nav className="grid grid-cols-[1fr_1fr_auto] gap-2 sm:flex sm:items-center" aria-label="账号导航"><span className="hidden max-w-36 truncate text-sm text-[#54707d] lg:inline">{user.username || user.email}</span><Link href="/my" className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl bg-white px-2 text-sm font-semibold text-[#155a4c] shadow-sm sm:px-3"><UserRound className="size-4 shrink-0" />我的智能柜</Link><Link href="/settings" className="inline-flex min-h-11 items-center justify-center gap-1.5 rounded-xl bg-white px-2 text-sm font-semibold text-[#155a4c] shadow-sm sm:px-3"><Settings2 className="size-4 shrink-0" />账号设置</Link><button onClick={() => void logout()} className="min-h-11 rounded-xl border border-[#b7cccd] px-3 text-sm font-semibold text-[#45626c]">退出</button></nav>
    </header>
    <section className="mt-10 grid gap-7 sm:mt-14 lg:grid-cols-[1fr_.9fr] lg:items-center"><div><p className="inline-flex items-center gap-2 rounded-full bg-[#d6f1e8] px-3 py-1.5 text-xs font-semibold text-[#155a4c] sm:text-sm"><Link2 className="size-4" />登录后，凭链接共享</p><h1 className="mt-5 max-w-xl text-[clamp(2rem,9vw,3rem)] font-extrabold leading-[1.14] tracking-tight sm:mt-6 sm:text-6xl">把照片和文件，<br /><span className="text-[#17836d]">放进同一个柜子。</span></h1><p className="mt-4 max-w-lg text-sm leading-7 text-[#54707d] sm:mt-5 sm:text-base sm:leading-8">按主题整理资料。把分享链接发给朋友或同事，对方登录后即可上传、查看和下载。</p><div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-sm text-[#46646d] sm:mt-8"><span className="inline-flex items-center gap-2"><Upload className="size-4 text-[#17836d]" />照片与文件</span><span className="inline-flex items-center gap-2"><Link2 className="size-4 text-[#17836d]" />链接权限</span></div></div>
      <div className="rounded-[1.75rem] border border-[#c1d6d5] bg-white p-2 shadow-[0_18px_45px_rgba(21,65,78,.11)] sm:p-7"><div className="grid gap-3 sm:gap-4"><section className="rounded-[1.35rem] bg-[#123047] p-5 text-white sm:rounded-2xl sm:p-6"><div className="flex items-center justify-between"><h2 className="text-xl font-bold sm:text-2xl">创建智能柜</h2><Plus className="size-6 text-[#75d3b8]" /></div><label className="mt-5 block text-sm font-medium text-[#c5e8df]">智能柜名称<input value={name} onChange={(event) => setName(event.target.value)} onKeyDown={(event) => event.key === "Enter" && void createCabinet(name)} maxLength={60} placeholder="例如：旅行照片" className="mt-2 w-full rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-base text-white outline-none placeholder:text-[#a7c5bf] focus:border-[#75d3b8]" /></label><button onClick={() => void createCabinet(name)} disabled={creating} className="mt-4 flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#75d3b8] px-4 py-3 font-semibold text-[#123047] disabled:opacity-60">{creating ? "正在创建…" : "创建并获取链接"}<ArrowRight className="size-4" /></button></section>
      <form onSubmit={joinCabinet} className="rounded-[1.35rem] border border-[#d2dfdf] p-5 sm:rounded-2xl sm:p-6"><h2 className="text-xl font-bold sm:text-2xl">加入智能柜</h2><p className="mt-1 text-sm text-[#55717a]">已有分享或管理链接</p><div className="mt-4 grid gap-2 min-[400px]:grid-cols-[minmax(0,1fr)_auto]"><input value={joinLink} onChange={(event) => setJoinLink(event.target.value)} placeholder="粘贴智能柜链接" className="min-w-0 w-full rounded-xl border border-[#c6d7d7] bg-white px-3 py-3 text-base outline-none focus:border-[#17836d]" /><button className="min-h-12 rounded-xl bg-[#e3f0ee] px-5 font-semibold text-[#155a4c]">加入</button></div></form></div></div></section>
    {created && <section className="mt-8 rounded-3xl border border-[#8bcdbd] bg-[#edfff8] p-4 sm:p-5"><div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between"><div className="min-w-0"><p className="break-words font-bold text-[#155a4c]">{created.cabinet.name} 已创建</p><p className="mt-1 text-sm text-[#46646d]">分享链接供成员使用；管理链接请妥善保管。</p></div><a href={new URL(created.adminUrl).pathname} className="inline-flex min-h-11 items-center justify-center rounded-xl bg-[#123047] px-4 py-2.5 font-semibold text-white">进入管理</a></div><div className="mt-4 grid gap-3 sm:grid-cols-2">{[["分享链接", created.shareUrl], ["管理链接", created.adminUrl]].map(([label, value]) => <div key={label} className="min-w-0 rounded-xl border border-[#b8e2d5] bg-white p-3"><div className="flex items-center justify-between gap-3"><p className="text-sm font-medium text-[#155a4c]">{label}</p><button onClick={() => void copy(value)} className="grid size-10 place-items-center rounded-lg text-[#17836d]" aria-label={`复制${label}`}><Copy className="size-4" /></button></div><p className="mt-1 truncate text-sm text-[#55717a]">{value}</p></div>)}</div></section>}
  </div></main>;
}
