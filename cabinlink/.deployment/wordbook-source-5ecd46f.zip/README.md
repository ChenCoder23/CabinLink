# 柜联 · CabinLink

一个登录后共享照片和文件的轻量网站。创建者建立“智能柜”和主题，通过分享链接邀请已登录用户上传、浏览和下载内容；管理操作由独立的管理链接或创建者账号完成。

## 功能

- 创建智能柜，生成独立的分享链接和管理链接
- 登录后通过分享链接查看、下载并上传照片或文件
- 使用主题整理不同批次的资料
- 图片网格预览，普通文件下载
- 创建者可创建、重命名、删除主题和文件，或关闭智能柜
- 可自行注册账号密码，或使用邮箱验证码登录；两种登录方式可绑定至同一账号
- 在“我的智能柜”中查看自己创建的空间
- 单文件最大 1 GB，单智能柜默认容量 10 GB
- 支持手机与桌面端界面

## 技术栈

- React / Vinext / TypeScript
- Cloudflare Worker 运行时
- D1（元数据）与 R2（文件对象）接口；本地 Docker 部署使用 Wrangler 本地持久化存储
- Drizzle ORM migrations
- Tailwind CSS 与 shadcn/ui

## 本地运行

需要 Node.js 22 或更新版本。

```bash
npm ci
npm run dev
```

打开终端提示的本地地址，通常为 `http://localhost:5173`。

邮箱验证码需要 Resend API Key、已验证发件域名，以及三个环境变量：`RESEND_API_KEY`、`RESEND_FROM_EMAIL`、`EMAIL_CODE_SECRET`。将 `.env.example` 复制为本地 `.env` 并填入实际值；密钥不要提交到仓库。未配置邮件服务时，账号密码注册和登录仍可使用。

## 常用命令

```bash
# 静态检查
npm run lint

# 生产构建
npm run build

# 修改数据库结构后生成迁移
npm run db:generate
```

## Docker 部署

项目提供 `Dockerfile` 和 `docker/start.sh`。容器启动时会自动应用 `drizzle/` 下尚未执行的 D1 迁移，并将本地持久化数据存放在挂载目录中。

```bash
docker build -t cabinlink:latest .
docker run -d --name cabinlink --restart unless-stopped -p 80:80 -v cabinlink_data:/data cabinlink:latest
```

使用邮箱登录的 Docker 部署还需通过容器环境变量传入上述三个值。启动脚本将它们作为 Worker Secret 读取；请使用部署平台的密钥管理功能，不要把密钥写入镜像。旧数据库会自动应用新增迁移，已有账号和智能柜保持可用。

> 生产环境建议在反向代理层配置 HTTPS。Cookie 在 HTTPS 下应增加 `Secure` 属性。

## 上传 GitHub 前的安全检查

本仓库的 `.gitignore` 已排除私钥、证书、环境变量、本地数据库、Wrangler 状态、构建产物和 `.secrets/`。

上传前请执行：

```bash
git status --ignored
git check-ignore -v .secrets/cabinlink_deploy
git grep -nE "BEGIN .*PRIVATE KEY|password[[:space:]]*[:=]|secret[[:space:]]*[:=]" || true
```

不要提交或粘贴以下内容：

- SSH 私钥、服务器密码、云厂商密钥
- `.env` 文件、R2/D1 生产凭据、真实管理链接
- `node_modules/`、`dist/`、`.wrangler/` 或运行时数据目录

若凭据曾被发送到公开渠道或提交到 Git 历史，请立即在对应服务中撤销并重新生成，而不是只删除文件。

## 项目结构

```text
app/          页面与 API 路由
components/   智能柜工作台和 UI 组件
db/           Drizzle 数据库定义
drizzle/      数据库迁移
lib/          鉴权、链接和复制工具
docker/       容器启动脚本
```

## 使用说明

1. 注册账号密码或使用邮箱验证码登录后创建智能柜，便于在“我的智能柜”中统一管理。
2. 创建主题，例如“旅行照片”或“项目资料”。
3. 将分享链接发送给协作成员；成员登录后即可使用。
4. 仅将管理链接留给创建者；它拥有修改和删除权限。

## 系统管理后台

访问 `/admin`，使用已有管理员账号登录。后台支持用户搜索和分页、用户/文件/存储统计、智能柜概览、重置密码、封禁和解封、强制退出、管理操作日志。统计中的有效会话不等于实时在线人数，最近会话时间只保留尚未删除的会话。

部署前先应用新增的 `drizzle/0006_admin_management.sql` 迁移（Docker 启动脚本自动应用迁移），再在目标数据库明确指定一个已注册账号：

```sql
UPDATE users SET role = 'admin' WHERE id = '要指定的用户ID' AND banned_at IS NULL;
```

没有默认管理员或默认密码。普通用户不能调用后台 API；后台不允许修改任何管理员账号，管理员自身密码使用个人设置修改。重置密码、封禁和强制退出会撤销已有会话及待用邮箱验证码。封禁不删除原有智能柜或文件，其他成员仍可使用共享内容。使用情况按智能柜所有者归属计算。邮箱用户重置密码后仍需在个人设置补全账号名才能使用账号密码登录。操作日志不保存密码。

## 链接获取和网站外观

智能柜管理页的“获取链接”可随时查看和复制分享链接、管理链接；系统管理员也可在后台智能柜列表获取链接。普通协作成员无权获取管理链接。新柜保存可恢复的链接，旧柜首次获取时建立新的固定链接，原有链接继续有效；关闭智能柜会使全部链接失效。`cabinet_links` 包含可恢复的管理凭证，请将数据库和备份作为敏感数据保管。

后台“网站设置”可独立设置电脑端标题（最多 40 字）、手机端标题（最多 20 字），并上传 PNG/JPEG/WebP Logo（最大 500 KB）或恢复默认 Logo。导航、登录页、浏览器标题和图标统一读取配置；手机标题在小于 640px 的屏幕显示。默认 Logo 为 `public/site-logo.png`。

部署前须应用 `0004_cabinet_links.sql`、`0005_site_settings.sql` 和管理员权限迁移；Docker 启动时自动应用迁移。本地验证命令：`node scripts/test-links-settings.mjs`。

## 单词本

登录后从首页进入 `/wordbook`。选择管理员创建的分类和日期，查看每日单词；支持遮蔽中文、遮蔽英文、点击揭晓及重新遮蔽。每个单词显示管理员上传时间（北京时间）。今天未发布时可选择已有单词的日期。

管理员在 `/admin#wordbook` 创建分类，下载 `.xlsx` 模板，填写“英文”“中文意思”，选择分类和发布日期后上传。每次最多 500 行、2 MB；不支持公式，空值、重复英文等错误会提示具体行号，整批不写入。每次上传追加一个批次；未来日期在当天开放，历史内容可回顾。

用户可创建带名字和颜色的个人标记，勾选单词后一键添加或移除（每次最多 500 个），并按标记筛选当前分类下所有已发布日期的单词。同名标记会更新颜色，标记和关联仅该账号可见。

上线前应用 `drizzle/0007_wordbook.sql`；Docker 启动脚本会自动应用新增迁移。已有数据不会被删除。接口验证：`node scripts/test-wordbook.mjs`。
