import { jsonError, requireStorage } from "@/lib/cabinet-server";
import { authorizeCabinet, sessionUser } from "@/lib/auth-server";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    if (!await sessionUser(request)) return jsonError("请先登录。", 401);
    const { id } = await params; const { db, bucket } = requireStorage(); const upload = await db.prepare("SELECT * FROM uploads WHERE id = ? AND expires_at > ?").bind(id, new Date().toISOString()).first<{ cabinet_id: string; theme_id: string; object_key: string; upload_id: string; original_name: string; content_type: string; size_bytes: number; parts_json: string }>(); if (!upload) return jsonError("上传已过期，请重新选择文件。", 404); const cabinet = await authorizeCabinet(request, upload.cabinet_id); if (!cabinet) return jsonError("智能柜链接无效。", 403); const parts = JSON.parse(upload.parts_json) as R2UploadedPart[]; if (!parts.length) return jsonError("尚未收到上传内容。"); await bucket.resumeMultipartUpload(upload.object_key, upload.upload_id).complete(parts); const fileId = crypto.randomUUID(); const now = new Date().toISOString(); await db.batch([db.prepare("INSERT INTO files (id, theme_id, object_key, original_name, content_type, size_bytes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)").bind(fileId, upload.theme_id, upload.object_key, upload.original_name, upload.content_type, upload.size_bytes, now), db.prepare("DELETE FROM uploads WHERE id = ?").bind(id)]); return Response.json({ file: { id: fileId, theme_id: upload.theme_id, original_name: upload.original_name, content_type: upload.content_type, size_bytes: upload.size_bytes, created_at: now } });
  } catch (error) { console.error(error); return jsonError("完成上传失败，请重试。", 500); }
}
